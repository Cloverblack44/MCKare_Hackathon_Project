# MCKare_Hackathon_Project
Project for team MCKare @U_Pitt Wireless Innovation for Accessbility Hackathon
